import time
import pandas as pd
import joblib

print("=" * 60)
print("EDGE AI SMART GLOVE - LIVE PREDICTION (SIMULATION)")
print("=" * 60)

# Load trained model
print("\nLoading model...")
model = joblib.load("models/random_forest_model.pkl")
print("Model loaded successfully!")

# Load feature dataset
print("\nLoading feature dataset...")
df = pd.read_csv("data/processed/features_dataset.csv")
print(f"Loaded {len(df)} samples.")

print("\nStarting live prediction...\n")
print("Press Ctrl + C to stop.\n")

while True:

    # Pick one random sample
    sample = df.sample(1)

    actual = sample["label"].iloc[0]

    # Remove non-feature columns
    X = sample.drop(columns=["sample_id", "label"])

    # Predict
    prediction = model.predict(X)[0]

    confidence = model.predict_proba(X).max() * 100

    print("-" * 50)
    print(f"Actual Gesture    : {actual}")
    print(f"Predicted Gesture : {prediction}")
    print(f"Confidence        : {confidence:.2f}%")

    if prediction == actual:
        print("Status            : Correct")
    else:
        print("Status            : Incorrect")

    time.sleep(2)