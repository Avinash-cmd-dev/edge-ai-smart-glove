import numpy as np
import random

GESTURES = ["wave", "fist", "point", "thumbs_up", "idle"]

def simulate_sensor_data(gesture=None):
    if not gesture:
        gesture = random.choice(GESTURES)
    
    # Simulate realistic sensor values per gesture
    base = {"wave": (0.5,0.2,0.1, 1.0,0.5,0.3),
            "fist": (-0.2,0.8,0.3, 0.1,0.2,1.5),
            "point": (0.8,0.1,0.4, 0.5,1.2,0.2),
            "thumbs_up": (0.1,0.9,-0.5, 0.8,0.3,0.4),
            "idle": (0.0,0.0,1.0, 0.0,0.0,0.0)}
    
    noise = np.random.normal(0, 0.1, 6)
    values = np.array(base.get(gesture, base["idle"])) + noise
    
    return {
        "ax": float(values[0]), "ay": float(values[1]), "az": float(values[2]),
        "gx": float(values[3]), "gy": float(values[4]), "gz": float(values[5])
    }